from .PySimpleGUI import *

if __name__ == "__main__":
    main_command_line()
    # main()
